require('angular');
require('../node_modules/angular-resource');
